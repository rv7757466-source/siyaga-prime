from __future__ import annotations
from discord.ext import commands
import discord
import aiosqlite
import typing
from typing import List
from utils.config import OWNER_IDS
from utils import getConfig
from .Context import Context
from colorama import Fore, Style, init

init(autoreset=True)

extensions: List[str] = ["cogs"]


class Olympus(commands.AutoShardedBot):
    def __init__(self, *args, **kwargs):
        intents = discord.Intents.all()
        intents.presences = True
        intents.members = True
        super().__init__(
            command_prefix=self.get_prefix,
            case_insensitive=True,
            intents=intents,
            status=discord.Status.online,
            strip_after_prefix=True,
            owner_ids=OWNER_IDS,
            allowed_mentions=discord.AllowedMentions(
                everyone=False, replied_user=False, roles=False
            ),
            sync_commands_debug=True,
            sync_commands=True,
            shard_count=2,
        )

    async def setup_hook(self):
        await self.load_extensions()

    async def load_extensions(self):
        for extension in extensions:
            try:
                await self.load_extension(extension)
                print(Fore.GREEN + Style.BRIGHT + f"Loaded extension: {extension}")
            except Exception as error:
                print(f"{Fore.RED}{Style.BRIGHT}Failed to load extension {extension}. {error}")
                raise
        print(Fore.GREEN + Style.BRIGHT + "*" * 20)

    async def on_connect(self):
        await self.change_presence(
            status=discord.Status.online,
            activity=discord.Activity(
                type=discord.ActivityType.listening,
                name="siyagaprime.site.je",
            ),
        )

    async def send_raw(
        self, channel_id: int, content: str, **kwargs
    ) -> typing.Optional[discord.Message]:
        await self.http.send_message(channel_id, content, **kwargs)

    async def invoke_help_command(self, ctx: Context) -> None:
        return await ctx.send_help(ctx.command)

    async def fetch_message_by_channel(
        self,
        channel: discord.TextChannel,
        message_id: int,
    ) -> typing.Optional[discord.Message]:
        async for message in channel.history(
            limit=1,
            before=discord.Object(message_id + 1),
            after=discord.Object(message_id - 1),
        ):
            return message
        return None

    async def get_prefix(self, message: discord.Message):
        async with aiosqlite.connect("db/np.db") as db:
            async with db.execute(
                "SELECT id FROM np WHERE id = ?", (message.author.id,)
            ) as cursor:
                no_prefix_user = await cursor.fetchone()

        if message.guild:
            data = await getConfig(message.guild.id)
            prefix = data["prefix"]
            if no_prefix_user:
                return commands.when_mentioned_or(prefix, "")(self, message)
            return commands.when_mentioned_or(prefix)(self, message)

        if no_prefix_user:
            return commands.when_mentioned_or("$", "")(self, message)
        return commands.when_mentioned_or("")(self, message)

    async def on_message_edit(self, before, after):
        if before.content == after.content or after.guild is None or after.author.bot:
            return
        context: Context = await self.get_context(after, cls=Context)
        if context.command is None:
            return
        await self.invoke(context)


def setup_bot():
    return Olympus(intents=discord.Intents.all())
