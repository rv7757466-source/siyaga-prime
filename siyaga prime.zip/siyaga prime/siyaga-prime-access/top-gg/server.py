import os

from app import app


if __name__ == "__main__":
	app.run(
		host=os.getenv("DASHBOARD_HOST", "127.0.0.1"),
		port=int(os.getenv("DASHBOARD_PORT", "8081")),
	)
