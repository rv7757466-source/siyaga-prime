import asyncio
import json
import os
import secrets
import time
from pathlib import Path
from urllib.parse import urlencode

import aiohttp
import aiosqlite
from quart import Blueprint, abort, current_app, jsonify, redirect, render_template, request, session, url_for


blueprint = Blueprint("dashboard", __name__, template_folder="templates", static_folder="static")
PROJECT_ROOT = Path(__file__).resolve().parents[2]
AUTOMOD_EVENTS = (
    "Anti spam",
    "Anti caps",
    "Anti link",
    "Anti invites",
    "Anti mass mention",
    "Anti emoji spam",
)
PUNISHMENTS = {"Mute", "Kick", "Ban"}
SESSIONS = {}


def _oauth_configured():
    return all(os.getenv(key) for key in ("DISCORD_CLIENT_ID", "DISCORD_CLIENT_SECRET", "DISCORD_REDIRECT_URI"))


def _session_data():
    session_id = session.get("control_session")
    data = SESSIONS.get(session_id)
    if not data or data["expires_at"] < time.time():
        if session_id:
            SESSIONS.pop(session_id, None)
        session.pop("control_session", None)
        return None
    return data


def _csrf_ok(data):
    supplied = request.headers.get("X-CSRF-Token", "")
    return bool(supplied) and secrets.compare_digest(supplied, data["csrf"])


async def _discord_request(method, endpoint, *, headers=None, **kwargs):
    timeout = aiohttp.ClientTimeout(total=12)
    async with aiohttp.ClientSession(timeout=timeout) as client:
        async with client.request(method, f"https://discord.com/api/v10{endpoint}", headers=headers, **kwargs) as response:
            try:
                payload = await response.json(content_type=None)
            except (aiohttp.ContentTypeError, json.JSONDecodeError):
                payload = {}
            return response.status, payload


def _bot_headers():
    token = os.getenv("TOKEN", "")
    return {"Authorization": f"Bot {token}"} if token else None


async def _manageable_guilds(data):
    user_headers = {"Authorization": f"Bearer {data['access_token']}"}
    status, guilds = await _discord_request("GET", "/users/@me/guilds", headers=user_headers)
    if status != 200 or not isinstance(guilds, list):
        return []

    bot_headers = _bot_headers()
    if not bot_headers:
        return []

    eligible = []
    for guild in guilds:
        permissions = int(guild.get("permissions", "0"))
        if not guild.get("owner") and not permissions & (0x8 | 0x20):
            continue
        eligible.append(guild)

    semaphore = asyncio.Semaphore(6)

    async def include_if_bot_is_present(guild):
        async with semaphore:
            bot_status, _ = await _discord_request("GET", f"/guilds/{guild['id']}", headers=bot_headers)
        if bot_status != 200:
            return None
        icon = guild.get("icon")
        return {
            "id": guild["id"],
            "name": guild["name"],
            "icon": f"https://cdn.discordapp.com/icons/{guild['id']}/{icon}.png?size=96" if icon else None,
        }

    results = await asyncio.gather(*(include_if_bot_is_present(guild) for guild in eligible))
    return [guild for guild in results if guild]


async def _guild_access(data, guild_id):
    guilds = await _manageable_guilds(data)
    return next((guild for guild in guilds if guild["id"] == str(guild_id)), None)


async def _guild_channels(guild_id):
    headers = _bot_headers()
    if not headers:
        return None
    status, channels = await _discord_request("GET", f"/guilds/{guild_id}/channels", headers=headers)
    if status != 200 or not isinstance(channels, list):
        return None
    return [
        {"id": str(channel["id"]), "name": channel["name"], "type": channel["type"]}
        for channel in channels
        if channel.get("type") in (0, 5)
    ]


async def _valid_channel(guild_id, channel_id):
    if not channel_id:
        return False
    channels = await _guild_channels(guild_id)
    return channels is not None and any(channel["id"] == str(channel_id) for channel in channels)


async def _ensure_settings_tables():
    async with aiosqlite.connect(PROJECT_ROOT / "db" / "prefix.db") as db:
        await db.execute("CREATE TABLE IF NOT EXISTS prefixes (guild_id INTEGER PRIMARY KEY, prefix TEXT NOT NULL)")
        await db.commit()
    async with aiosqlite.connect(PROJECT_ROOT / "db" / "automod.db") as db:
        await db.execute("CREATE TABLE IF NOT EXISTS automod (guild_id INTEGER PRIMARY KEY, enabled INTEGER DEFAULT 0)")
        await db.execute("CREATE TABLE IF NOT EXISTS automod_punishments (guild_id INTEGER, event TEXT, punishment TEXT, PRIMARY KEY (guild_id, event))")
        await db.execute("CREATE TABLE IF NOT EXISTS automod_logging (guild_id INTEGER PRIMARY KEY, log_channel INTEGER)")
        await db.commit()
    async with aiosqlite.connect(PROJECT_ROOT / "db" / "welcome.db") as db:
        await db.execute("""CREATE TABLE IF NOT EXISTS welcome (
            guild_id INTEGER PRIMARY KEY,
            welcome_type TEXT,
            welcome_message TEXT,
            channel_id INTEGER,
            embed_data TEXT,
            auto_delete_duration INTEGER
        )""")
        await db.commit()


@blueprint.get("/dashboard")
async def index():
    data = _session_data()
    return await render_template(
        "dashboard.html",
        authenticated=data is not None,
        oauth_configured=_oauth_configured() and bool(os.getenv("TOKEN")),
        user=data["user"] if data else None,
        csrf=data["csrf"] if data else "",
    )


@blueprint.get("/dashboard/login")
async def login():
    if not _oauth_configured() or not os.getenv("TOKEN"):
        return redirect(url_for("dashboard.index"))
    state = secrets.token_urlsafe(32)
    session["oauth_state"] = state
    session.permanent = True
    params = urlencode({
        "client_id": os.environ["DISCORD_CLIENT_ID"],
        "redirect_uri": os.environ["DISCORD_REDIRECT_URI"],
        "response_type": "code",
        "scope": "identify guilds",
        "state": state,
    })
    return redirect(f"https://discord.com/oauth2/authorize?{params}")


@blueprint.get("/dashboard/callback")
async def callback():
    if request.args.get("error"):
        return redirect(url_for("dashboard.index"))
    state = request.args.get("state", "")
    expected_state = session.pop("oauth_state", "")
    if not state or not expected_state or not secrets.compare_digest(state, expected_state):
        abort(400)
    code = request.args.get("code")
    if not code or not _oauth_configured():
        abort(400)

    token_status, token_data = await _discord_request(
        "POST",
        "/oauth2/token",
        data={
            "client_id": os.environ["DISCORD_CLIENT_ID"],
            "client_secret": os.environ["DISCORD_CLIENT_SECRET"],
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": os.environ["DISCORD_REDIRECT_URI"],
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    if token_status != 200 or not token_data.get("access_token"):
        abort(401)

    access_token = token_data["access_token"]
    user_status, user = await _discord_request(
        "GET", "/users/@me", headers={"Authorization": f"Bearer {access_token}"}
    )
    if user_status != 200:
        abort(401)

    session_id = secrets.token_urlsafe(32)
    avatar = user.get("avatar")
    SESSIONS[session_id] = {
        "access_token": access_token,
        "user": {
            "id": user["id"],
            "name": user.get("global_name") or user.get("username", "Discord user"),
            "avatar": f"https://cdn.discordapp.com/avatars/{user['id']}/{avatar}.png?size=96" if avatar else None,
        },
        "csrf": secrets.token_urlsafe(32),
        "expires_at": time.time() + min(int(token_data.get("expires_in", 3600)), 3600),
    }
    session.clear()
    session["control_session"] = session_id
    session.permanent = True
    return redirect(url_for("dashboard.index"))


@blueprint.post("/dashboard/logout")
async def logout():
    data = _session_data()
    if data and _csrf_ok(data):
        SESSIONS.pop(session.get("control_session"), None)
    session.clear()
    return redirect(url_for("dashboard.index"))


@blueprint.get("/dashboard/api/guilds")
async def guilds():
    data = _session_data()
    if not data:
        return jsonify({"error": "login_required"}), 401
    return jsonify({"guilds": await _manageable_guilds(data)})


@blueprint.get("/dashboard/api/guilds/<guild_id>/channels")
async def channels(guild_id):
    data = _session_data()
    if not data:
        return jsonify({"error": "login_required"}), 401
    if not await _guild_access(data, guild_id):
        return jsonify({"error": "guild_forbidden"}), 403
    result = await _guild_channels(guild_id)
    if result is None:
        return jsonify({"error": "bot_unavailable"}), 502
    return jsonify({"channels": result})


@blueprint.get("/dashboard/api/guilds/<guild_id>/settings")
async def get_settings(guild_id):
    data = _session_data()
    if not data:
        return jsonify({"error": "login_required"}), 401
    guild = await _guild_access(data, guild_id)
    if not guild:
        return jsonify({"error": "guild_forbidden"}), 403

    await _ensure_settings_tables()
    async with aiosqlite.connect(PROJECT_ROOT / "db" / "prefix.db") as db:
        async with db.execute("SELECT prefix FROM prefixes WHERE guild_id = ?", (int(guild_id),)) as cursor:
            prefix_row = await cursor.fetchone()
    async with aiosqlite.connect(PROJECT_ROOT / "db" / "automod.db") as db:
        async with db.execute("SELECT enabled FROM automod WHERE guild_id = ?", (int(guild_id),)) as cursor:
            automod_row = await cursor.fetchone()
        async with db.execute("SELECT event, punishment FROM automod_punishments WHERE guild_id = ?", (int(guild_id),)) as cursor:
            punishment_rows = await cursor.fetchall()
        async with db.execute("SELECT log_channel FROM automod_logging WHERE guild_id = ?", (int(guild_id),)) as cursor:
            log_row = await cursor.fetchone()
    async with aiosqlite.connect(PROJECT_ROOT / "db" / "welcome.db") as db:
        async with db.execute("SELECT welcome_type, welcome_message, channel_id, embed_data, auto_delete_duration FROM welcome WHERE guild_id = ?", (int(guild_id),)) as cursor:
            welcome_row = await cursor.fetchone()

    configured_events = {event: punishment for event, punishment in punishment_rows}
    welcome = None
    if welcome_row:
        welcome = {
            "type": welcome_row[0] or "simple",
            "message": welcome_row[1] or "",
            "channel_id": str(welcome_row[2]) if welcome_row[2] else "",
            "embed_data": json.loads(welcome_row[3]) if welcome_row[3] else {},
            "auto_delete_duration": welcome_row[4] or 0,
        }
    return jsonify({
        "guild": guild,
        "prefix": prefix_row[0] if prefix_row else "$",
        "automod": {
            "enabled": bool(automod_row and automod_row[0]),
            "events": [
                {"name": event, "enabled": event in configured_events, "punishment": configured_events.get(event, "Mute")}
                for event in AUTOMOD_EVENTS
            ],
            "log_channel_id": str(log_row[0]) if log_row and log_row[0] else "",
        },
        "welcome": welcome,
    })


@blueprint.patch("/dashboard/api/guilds/<guild_id>/settings")
async def update_settings(guild_id):
    data = _session_data()
    if not data:
        return jsonify({"error": "login_required"}), 401
    if not _csrf_ok(data):
        return jsonify({"error": "csrf_failed"}), 403
    if not await _guild_access(data, guild_id):
        return jsonify({"error": "guild_forbidden"}), 403

    payload = await request.get_json(silent=True) or {}
    guild_id_int = int(guild_id)
    channels_to_check = []
    automod = payload.get("automod")
    welcome = payload.get("welcome")

    if "prefix" in payload:
        prefix = payload["prefix"]
        if not isinstance(prefix, str) or not 1 <= len(prefix) <= 5 or any(char.isspace() or ord(char) < 32 for char in prefix):
            return jsonify({"error": "invalid_prefix", "message": "Prefix must be 1-5 non-space characters."}), 400

    if automod is not None:
        if not isinstance(automod, dict) or not isinstance(automod.get("enabled"), bool):
            return jsonify({"error": "invalid_automod"}), 400
        events = automod.get("events", [])
        if not isinstance(events, list):
            return jsonify({"error": "invalid_events"}), 400
        seen = set()
        for item in events:
            if not isinstance(item, dict) or item.get("name") not in AUTOMOD_EVENTS or item["name"] in seen:
                return jsonify({"error": "invalid_events"}), 400
            if item.get("enabled") and item.get("punishment", "Mute") not in PUNISHMENTS:
                return jsonify({"error": "invalid_punishment"}), 400
            seen.add(item["name"])
        if automod["enabled"] and not any(item.get("enabled") for item in events):
            return jsonify({"error": "select_event", "message": "Enable at least one automod rule."}), 400
        if automod.get("log_channel_id"):
            channels_to_check.append(automod["log_channel_id"])

    if welcome is not None:
        if not isinstance(welcome, dict) or not isinstance(welcome.get("enabled"), bool):
            return jsonify({"error": "invalid_welcome"}), 400
        if welcome["enabled"]:
            kind = welcome.get("type", "simple")
            message = welcome.get("message", "")
            title = welcome.get("title", "")
            if kind not in {"simple", "embed"} or not isinstance(message, str) or len(message) > 2000 or not isinstance(title, str) or len(title) > 256:
                return jsonify({"error": "invalid_welcome_content"}), 400
            if kind == "simple" and not message.strip():
                return jsonify({"error": "empty_welcome", "message": "Add a welcome message before saving."}), 400
            if kind == "embed" and not (message.strip() or title.strip()):
                return jsonify({"error": "empty_welcome", "message": "Add an embed title or description before saving."}), 400
            duration = welcome.get("auto_delete_duration", 0)
            if not isinstance(duration, int) or not 0 <= duration <= 86400:
                return jsonify({"error": "invalid_duration"}), 400
            channel_id = welcome.get("channel_id", "")
            if not channel_id:
                return jsonify({"error": "select_channel", "message": "Select a welcome channel."}), 400
            channels_to_check.append(channel_id)

    available_channels = None
    if channels_to_check:
        available_channels = await _guild_channels(guild_id)
        if available_channels is None:
            return jsonify({"error": "bot_unavailable"}), 502
        available_ids = {channel["id"] for channel in available_channels}
        if any(str(channel_id) not in available_ids for channel_id in channels_to_check):
            return jsonify({"error": "invalid_channel", "message": "Choose a text channel in this server."}), 400

    await _ensure_settings_tables()
    if "prefix" in payload:
        async with aiosqlite.connect(PROJECT_ROOT / "db" / "prefix.db") as db:
            await db.execute(
                "INSERT INTO prefixes (guild_id, prefix) VALUES (?, ?) ON CONFLICT(guild_id) DO UPDATE SET prefix = excluded.prefix",
                (guild_id_int, payload["prefix"]),
            )
            await db.commit()

    if automod is not None:
        async with aiosqlite.connect(PROJECT_ROOT / "db" / "automod.db") as db:
            await db.execute(
                "INSERT INTO automod (guild_id, enabled) VALUES (?, ?) ON CONFLICT(guild_id) DO UPDATE SET enabled = excluded.enabled",
                (guild_id_int, int(automod["enabled"])),
            )
            if "events" in automod:
                await db.execute("DELETE FROM automod_punishments WHERE guild_id = ? AND event != 'Anti NSFW link'", (guild_id_int,))
                for item in automod["events"]:
                    if item.get("enabled"):
                        await db.execute(
                            "INSERT OR REPLACE INTO automod_punishments (guild_id, event, punishment) VALUES (?, ?, ?)",
                            (guild_id_int, item["name"], item.get("punishment", "Mute")),
                        )
            if "log_channel_id" in automod:
                if automod["log_channel_id"]:
                    await db.execute(
                        "INSERT INTO automod_logging (guild_id, log_channel) VALUES (?, ?) ON CONFLICT(guild_id) DO UPDATE SET log_channel = excluded.log_channel",
                        (guild_id_int, int(automod["log_channel_id"])),
                    )
                else:
                    await db.execute("DELETE FROM automod_logging WHERE guild_id = ?", (guild_id_int,))
            await db.commit()

    if welcome is not None:
        async with aiosqlite.connect(PROJECT_ROOT / "db" / "welcome.db") as db:
            if not welcome["enabled"]:
                await db.execute("DELETE FROM welcome WHERE guild_id = ?", (guild_id_int,))
            else:
                kind = welcome.get("type", "simple")
                message = welcome.get("message", "").strip()
                embed_data = None
                welcome_message = message if kind == "simple" else ""
                if kind == "embed":
                    embed_data = json.dumps({
                        "message": message,
                        "title": welcome.get("title", "").strip(),
                        "description": message,
                        "color": welcome.get("color", "#257A69"),
                    })
                await db.execute(
                    """INSERT INTO welcome (guild_id, welcome_type, welcome_message, channel_id, embed_data, auto_delete_duration)
                    VALUES (?, ?, ?, ?, ?, ?)
                    ON CONFLICT(guild_id) DO UPDATE SET welcome_type = excluded.welcome_type,
                    welcome_message = excluded.welcome_message, channel_id = excluded.channel_id,
                    embed_data = excluded.embed_data, auto_delete_duration = excluded.auto_delete_duration""",
                    (guild_id_int, kind, welcome_message, int(welcome["channel_id"]), embed_data, welcome.get("auto_delete_duration", 0)),
                )
            await db.commit()

    return jsonify({"ok": True})


def register_dashboard(app):
    app.register_blueprint(blueprint)
