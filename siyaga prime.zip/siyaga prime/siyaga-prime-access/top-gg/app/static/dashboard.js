(() => {
  const root = document.getElementById('dashboard');
  if (!root) return;

  const csrf = window.DASHBOARD_CONTEXT.csrf;
  const guildSelect = document.getElementById('guild-select');
  const content = document.getElementById('page-content');
  const breadcrumb = document.getElementById('breadcrumb-current');
  const navCount = document.getElementById('automod-nav-count');
  const sidebar = document.getElementById('sidebar');
  let guilds = [];
  let settings = null;
  let channels = [];
  let currentPage = 'overview';
  let busy = false;

  const escapeHTML = (value = '') => String(value).replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[char]);

  function toast(message, isError = false) {
    const region = document.getElementById('toast-region');
    const item = document.createElement('div');
    item.className = `toast${isError ? ' error' : ''}`;
    item.textContent = message;
    region.appendChild(item);
    window.setTimeout(() => item.remove(), 3400);
  }

  async function api(url, options = {}) {
    const response = await fetch(url, {
      credentials: 'same-origin',
      ...options,
      headers: {
        ...(options.body ? { 'Content-Type': 'application/json' } : {}),
        ...(options.method && options.method !== 'GET' ? { 'X-CSRF-Token': csrf } : {}),
        ...(options.headers || {})
      }
    });
    let data = {};
    try { data = await response.json(); } catch (_) { /* handled below */ }
    if (!response.ok) {
      if (response.status === 401) window.location.assign('/dashboard');
      throw new Error(data.message || data.error || `Request failed (${response.status})`);
    }
    return data;
  }

  function selectedGuild() {
    return guilds.find(guild => guild.id === guildSelect.value) || null;
  }

  function heading(kicker, title, description, suffix = '') {
    const guild = selectedGuild();
    return `<div class="page-heading"><div><span class="section-kicker">${escapeHTML(kicker)}</span><h1>${escapeHTML(title)}</h1><p>${escapeHTML(description)}</p></div>${guild ? `<div class="guild-context"><span class="context-mark">S</span>${escapeHTML(guild.name.toUpperCase())}${suffix}</div>` : ''}</div>`;
  }

  function renderOverview() {
    const guild = selectedGuild();
    const enabled = settings.automod.enabled;
    const activeRules = settings.automod.events.filter(rule => rule.enabled).length;
    const welcomeReady = Boolean(settings.welcome);
    content.innerHTML = `${heading('SERVER OPERATIONS / 01', 'Server overview', 'A quick read on the settings currently managed by Siyaga Prime.')}
      <section class="overview-band"><div class="overview-copy"><span class="section-kicker">CONTROL STATUS</span><h2>${enabled ? 'Protection is on.' : 'Your server, at a glance.'}</h2><p>${enabled ? `${activeRules} automod rules are active for ${escapeHTML(guild.name)}.` : `Configure the essentials for ${escapeHTML(guild.name)} from one workspace.`} Settings save directly to the bot’s live configuration.</p></div><div class="overview-side"><span>SELECTED SERVER</span><strong>${escapeHTML(guild.name)}</strong><small>${enabled ? 'Automod enabled' : 'Automod not configured'}</small></div></section>
      <section class="metric-strip"><div class="metric"><span class="metric-label">COMMAND PREFIX</span><strong class="metric-value">${escapeHTML(settings.prefix)}</strong></div><div class="metric"><span class="metric-label">AUTOMOD RULES</span><strong class="metric-value">${activeRules} / ${settings.automod.events.length}</strong></div><div class="metric"><span class="metric-label">WELCOME FLOW</span><strong class="metric-value">${welcomeReady ? 'Configured' : 'Not set'}</strong></div></section>
      <div class="section-title-row"><h2>Configuration shortcuts</h2><span>03 SETTINGS AREAS</span></div><div class="quick-list">
        ${quickRow('⌘', 'General settings', `Prefix is currently ${settings.prefix}.`, 'general')}
        ${quickRow('⛨', 'Automod', enabled ? `${activeRules} active rules protect this server.` : 'Choose rules, punishments, and a log channel.', 'automod')}
        ${quickRow('✳', 'Welcome', welcomeReady ? `Posting to ${channelName(settings.welcome.channel_id)}.` : 'Create or update the member welcome flow.', 'welcome')}
      </div>`;
  }

  function quickRow(icon, title, subtitle, page) {
    return `<button class="quick-row" data-goto="${page}"><span class="quick-symbol">${icon}</span><span class="quick-copy"><strong>${escapeHTML(title)}</strong><small>${escapeHTML(subtitle)}</small></span><span class="quick-state">OPEN</span><span class="quick-arrow">›</span></button>`;
  }

  function channelName(id) {
    const channel = channels.find(item => item.id === String(id));
    return channel ? `#${channel.name}` : 'selected channel';
  }

  function renderGeneral() {
    content.innerHTML = `${heading('CONFIGURATION / 01', 'General settings', 'A small setting with a big impact on how people use the bot.')}
      <div class="settings-layout"><div class="settings-main"><section class="form-section"><h2>Command prefix</h2><p>Set the character members type before a command. Mentioning the bot continues to work.</p><label class="field-label" for="prefix-input">PREFIX</label><input id="prefix-input" class="field-input" maxlength="5" value="${escapeHTML(settings.prefix)}" autocomplete="off"><div class="field-help">Use 1–5 characters with no spaces. Current example: <code>${escapeHTML(settings.prefix)}help</code>.</div><div class="form-actions"><button class="button button-primary button-small" id="save-prefix">Save prefix <span>↗</span></button></div></section></div><aside class="settings-aside"><div class="aside-block"><h3>HOW IT APPLIES</h3><p>The bot reads guild prefixes from its shared database. New servers default to <code>$</code>; this value only changes the selected server.</p></div><div class="aside-block"><h3>PERMISSIONS</h3><p>Only a server owner or member with Manage Server can change this setting.</p></div></aside></div>`;
    document.getElementById('save-prefix').addEventListener('click', async event => {
      const button = event.currentTarget;
      const value = document.getElementById('prefix-input').value.trim();
      await save(button, { prefix: value });
    });
  }

  function renderAutomod() {
    const automod = settings.automod;
    const channelsHtml = channelOptions(automod.log_channel_id, true);
    content.innerHTML = `${heading('CONFIGURATION / 02', 'Automod', 'Choose the protections that run and where moderation events are recorded.')}
      <div class="settings-layout"><div class="settings-main">
        <section class="form-section"><h2>Protection status</h2><p>When disabled, stored rules remain available to turn back on.</p><div class="switch-line"><span class="switch-copy"><strong>Enable automod</strong><small>Apply the enabled rules to this server.</small></span>${toggle('automod-enabled', automod.enabled, 'Enable automod')}</div></section>
        <section class="form-section"><h2>Detection rules</h2><p>Each enabled rule uses the bot’s standard punishment behavior.</p><div class="rule-table">${automod.events.map((rule, index) => `<div class="rule-row"><span class="rule-name">${escapeHTML(rule.name)}<small class="rule-description">${ruleCopy(rule.name)}</small></span><select class="field-select punishment-select" data-index="${index}" aria-label="Punishment for ${escapeHTML(rule.name)}"><option${rule.punishment === 'Mute' ? ' selected' : ''}>Mute</option><option${rule.punishment === 'Kick' ? ' selected' : ''}>Kick</option><option${rule.punishment === 'Ban' ? ' selected' : ''}>Ban</option></select>${toggle(`rule-${index}`, rule.enabled, `Enable ${rule.name}`, `data-rule-index="${index}"`)}</div>`).join('')}</div></section>
        <section class="form-section"><h2>Moderation log</h2><p>Choose a channel where automod records actions. Leave blank to disable logging.</p><label class="field-label" for="automod-channel">LOG CHANNEL</label><select class="field-select" id="automod-channel">${channelsHtml}</select><div class="form-actions"><button class="button button-primary button-small" id="save-automod">Save automod settings <span>↗</span></button></div></section>
      </div><aside class="settings-aside"><div class="aside-block"><h3>RULE INVENTORY</h3><p>Spam, caps, links, invites, mass mentions, and emoji spam are configurable here. NSFW-link filtering uses Discord AutoMod setup inside Discord.</p></div><div class="aside-block"><h3>SAFE DEFAULT</h3><p>Newly enabled rules default to Mute. Check your bot’s role position and permissions before choosing Kick or Ban.</p></div></aside></div>`;
    document.getElementById('save-automod').addEventListener('click', async event => {
      const button = event.currentTarget;
      const rules = automod.events.map((rule, index) => ({
        name: rule.name,
        enabled: document.getElementById(`rule-${index}`).checked,
        punishment: document.querySelector(`.punishment-select[data-index="${index}"]`).value
      }));
      await save(button, { automod: {
        enabled: document.getElementById('automod-enabled').checked,
        events: rules,
        log_channel_id: document.getElementById('automod-channel').value
      } });
    });
  }

  function ruleCopy(name) {
    return ({
      'Anti spam': 'Repeated messages and rapid posting',
      'Anti caps': 'Messages with excessive uppercase text',
      'Anti link': 'Unapproved external links',
      'Anti invites': 'Discord server invitations',
      'Anti mass mention': 'Messages tagging many members',
      'Anti emoji spam': 'Excessive emoji in a message'
    })[name] || 'Automated moderation rule';
  }

  function toggle(id, checked, label, extra = '') {
    return `<label class="switch" aria-label="${escapeHTML(label)}"><input type="checkbox" id="${id}" ${checked ? 'checked' : ''} ${extra}><span class="switch-track"></span></label>`;
  }

  function channelOptions(selected, allowEmpty = false) {
    const empty = allowEmpty ? '<option value="">No log channel</option>' : '<option value="">Select a channel</option>';
    return empty + channels.map(channel => `<option value="${escapeHTML(channel.id)}" ${channel.id === String(selected || '') ? 'selected' : ''}># ${escapeHTML(channel.name)}</option>`).join('');
  }

  function renderWelcome() {
    const welcome = settings.welcome || { type: 'simple', message: '', channel_id: '', embed_data: {}, auto_delete_duration: 0 };
    const embed = welcome.embed_data || {};
    const currentMessage = welcome.type === 'embed' ? (embed.description || '') : welcome.message;
    const channelOpts = channelOptions(welcome.channel_id);
    content.innerHTML = `${heading('CONFIGURATION / 03', 'Welcome flow', 'Set a consistent first message when a member joins.')}
      <div class="settings-layout"><div class="settings-main">
        <section class="form-section"><h2>Welcome status</h2><p>Switching off removes this server’s saved welcome configuration.</p><div class="switch-line"><span class="switch-copy"><strong>Enable welcome message</strong><small>Send the configured welcome when a new member joins.</small></span>${toggle('welcome-enabled', Boolean(settings.welcome), 'Enable welcome message')}</div></section>
        <section class="form-section"><h2>Message format</h2><p>Use plain text or an embed. Both support the existing welcome placeholders.</p><label class="field-label" for="welcome-type">FORMAT</label><select class="field-select" id="welcome-type"><option value="simple"${welcome.type !== 'embed' ? ' selected' : ''}>Plain message</option><option value="embed"${welcome.type === 'embed' ? ' selected' : ''}>Embed</option></select><div id="welcome-title-wrap" ${welcome.type !== 'embed' ? 'hidden' : ''}><label class="field-label" for="welcome-title">EMBED TITLE</label><input class="field-input" id="welcome-title" maxlength="256" value="${escapeHTML(embed.title || '')}" placeholder="Welcome to {server_name}"></div><label class="field-label" for="welcome-message" id="welcome-message-label">${welcome.type === 'embed' ? 'DESCRIPTION' : 'MESSAGE'}</label><textarea class="field-textarea" id="welcome-message" maxlength="2000" placeholder="Welcome {user} to {server_name}!">${escapeHTML(currentMessage)}</textarea></section>
        <section class="form-section"><h2>Delivery</h2><p>Select a text channel visible to the bot.</p><label class="field-label" for="welcome-channel">WELCOME CHANNEL</label><select class="field-select" id="welcome-channel">${channelOpts}</select><label class="field-label" for="welcome-delete">AUTO DELETE</label><select class="field-select" id="welcome-delete"><option value="0">Keep message</option><option value="30"${welcome.auto_delete_duration === 30 ? ' selected' : ''}>After 30 seconds</option><option value="60"${welcome.auto_delete_duration === 60 ? ' selected' : ''}>After 1 minute</option><option value="300"${welcome.auto_delete_duration === 300 ? ' selected' : ''}>After 5 minutes</option><option value="3600"${welcome.auto_delete_duration === 3600 ? ' selected' : ''}>After 1 hour</option></select><div class="form-actions"><button class="button button-primary button-small" id="save-welcome">Save welcome settings <span>↗</span></button>${settings.welcome ? '<button class="button button-danger button-small" id="clear-welcome">Remove setup</button>' : ''}</div></section>
      </div><aside class="settings-aside"><div class="aside-block"><h3>AVAILABLE PLACEHOLDERS</h3><p>Use these values in message text. They’re filled when the member joins.</p><div class="placeholder-list"><code>{user}</code><code>{user_name}</code><code>{user_nick}</code><code>{server_name}</code><code>{server_membercount}</code><code>{user_createdate}</code><code>{timestamp}</code></div></div><div class="aside-block"><h3>MESSAGE LIMIT</h3><p>Messages are limited to 2,000 characters. The bot must be able to view and send messages in the selected channel.</p></div></aside></div>`;
    const typeSelect = document.getElementById('welcome-type');
    typeSelect.addEventListener('change', () => {
      const isEmbed = typeSelect.value === 'embed';
      document.getElementById('welcome-title-wrap').hidden = !isEmbed;
      document.getElementById('welcome-message-label').textContent = isEmbed ? 'DESCRIPTION' : 'MESSAGE';
    });
    document.getElementById('save-welcome').addEventListener('click', async event => {
      const button = event.currentTarget;
      const type = typeSelect.value;
      await save(button, { welcome: {
        enabled: document.getElementById('welcome-enabled').checked,
        type,
        title: document.getElementById('welcome-title').value,
        message: document.getElementById('welcome-message').value,
        color: '#17634f',
        channel_id: document.getElementById('welcome-channel').value,
        auto_delete_duration: Number(document.getElementById('welcome-delete').value)
      } });
    });
    const clear = document.getElementById('clear-welcome');
    if (clear) clear.addEventListener('click', async event => {
      if (!window.confirm('Remove this server’s saved welcome configuration?')) return;
      await save(event.currentTarget, { welcome: { enabled: false } });
    });
  }

  async function save(button, payload) {
    if (busy) return;
    busy = true;
    const original = button.innerHTML;
    button.disabled = true;
    button.textContent = 'Saving…';
    try {
      await api(`/dashboard/api/guilds/${guildSelect.value}/settings`, {
        method: 'PATCH',
        body: JSON.stringify(payload)
      });
      await loadSettings(false);
      toast('Settings saved.');
    } catch (error) {
      toast(error.message || 'Could not save settings.', true);
    } finally {
      busy = false;
      button.disabled = false;
      button.innerHTML = original;
    }
  }

  function renderPage() {
    if (!settings) return;
    const labels = { overview: 'OVERVIEW', general: 'GENERAL', automod: 'AUTOMOD', welcome: 'WELCOME' };
    breadcrumb.textContent = labels[currentPage] || 'OVERVIEW';
    document.querySelectorAll('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.page === currentPage));
    if (currentPage === 'general') renderGeneral();
    else if (currentPage === 'automod') renderAutomod();
    else if (currentPage === 'welcome') renderWelcome();
    else renderOverview();
    content.querySelectorAll('[data-goto]').forEach(button => button.addEventListener('click', () => navigate(button.dataset.goto)));
  }

  function navigate(page) {
    currentPage = page;
    renderPage();
    sidebar.classList.remove('open');
    document.querySelector('.mobile-backdrop')?.classList.remove('open');
  }

  async function loadSettings(showLoading = true) {
    if (!guildSelect.value) return;
    if (showLoading) content.innerHTML = '<div class="loading-state"><span class="loader"></span><span>Loading server settings</span></div>';
    try {
      const [result, channelResult] = await Promise.all([
        api(`/dashboard/api/guilds/${guildSelect.value}/settings`),
        api(`/dashboard/api/guilds/${guildSelect.value}/channels`)
      ]);
      settings = result;
      channels = channelResult.channels;
      const active = settings.automod.events.filter(rule => rule.enabled).length;
      navCount.textContent = `${active}/${settings.automod.events.length}`;
      renderPage();
    } catch (error) {
      content.innerHTML = `<div class="error-state"><strong>Could not load this server</strong><span>${escapeHTML(error.message)}</span></div>`;
    }
  }

  async function loadGuilds() {
    try {
      const result = await api('/dashboard/api/guilds');
      guilds = result.guilds;
      guildSelect.innerHTML = guilds.length
        ? guilds.map(guild => `<option value="${escapeHTML(guild.id)}">${escapeHTML(guild.name)}</option>`).join('')
        : '<option value="">No manageable servers with the bot installed</option>';
      if (!guilds.length) {
        content.innerHTML = '<div class="error-state"><strong>No server available</strong><span>Add Siyaga Prime to a server you own or manage, then reload.</span></div>';
        return;
      }
      await loadSettings();
    } catch (error) {
      content.innerHTML = `<div class="error-state"><strong>Could not load servers</strong><span>${escapeHTML(error.message)}</span></div>`;
    }
  }

  guildSelect.addEventListener('change', () => { settings = null; loadSettings(); });
  document.querySelectorAll('.nav-item').forEach(item => item.addEventListener('click', () => navigate(item.dataset.page)));
  document.getElementById('mobile-menu').addEventListener('click', () => {
    sidebar.classList.add('open');
    document.querySelector('.mobile-backdrop').classList.add('open');
  });
  document.querySelector('.mobile-backdrop').addEventListener('click', () => {
    sidebar.classList.remove('open');
    document.querySelector('.mobile-backdrop').classList.remove('open');
  });
  loadGuilds();
})();
