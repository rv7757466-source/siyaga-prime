# Siyaga Prime Dashboard Setup

The dashboard runs beside the bot and reads/writes the bot's existing SQLite settings. Discord OAuth is required before any server settings are shown or changed.

## Discord OAuth

1. In the Discord Developer Portal, use the application with client ID `1548707273545748560` and copy its OAuth2 client secret.
2. Add this exact redirect URI for local development: `http://127.0.0.1:8081/dashboard/callback`.
3. The dashboard requests the `identify` and `guilds` OAuth scopes. These are sufficient to identify the user and list manageable servers; `guilds.join` and `connections` are not needed. The bot must already be installed in the server.
4. Add these values to the active project `.env` file. Do not commit the file or share the client secret in chat:

```env
DISCORD_CLIENT_ID=1548707273545748560
DISCORD_CLIENT_SECRET=your_rotated_client_secret
DISCORD_REDIRECT_URI=http://127.0.0.1:8081/dashboard/callback
DASHBOARD_SECRET_KEY=generate_a_long_random_secret
DASHBOARD_HOST=127.0.0.1
DASHBOARD_PORT=8081
DASHBOARD_COOKIE_SECURE=false
```

For production, use HTTPS, set `DASHBOARD_COOKIE_SECURE=true`, set the public HTTPS callback URI in both Discord and `.env`, and provide a stable random `DASHBOARD_SECRET_KEY` through the hosting provider's secret manager. Never expose the bot token or OAuth client secret in browser code.

## Run Locally

From the active project root:

```powershell
python -m pip install -r top-gg/requirements.txt
python top-gg/server.py
```

Open `http://127.0.0.1:8081/dashboard`. The dashboard lists only servers where the signed-in user owns the server or has Manage Server permission and the bot is present.

The first dashboard controls are general prefix, automod rules/punishments/log channel, and welcome message/channel. Other command systems are not editable from the dashboard until a settings API is added for them.
