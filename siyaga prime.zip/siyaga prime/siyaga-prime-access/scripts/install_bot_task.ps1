$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $PSScriptRoot
$envPath = Join-Path $projectRoot ".env"
$taskName = "SiyagaPrimeBot"

if (-not (Test-Path -LiteralPath $envPath)) {
    throw "The project .env file is missing. Configure TOKEN before installing the startup task."
}

$envContents = Get-Content -LiteralPath $envPath -Raw
if (-not [regex]::IsMatch($envContents, "(?m)^TOKEN\s*=\s*\S+")) {
    throw "TOKEN is not configured in .env. Add it privately before installing the startup task."
}

$python = (Get-Command python.exe -ErrorAction Stop).Source
$currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$botEntry = Join-Path $projectRoot "main.py"
$action = New-ScheduledTaskAction -Execute $python -Argument "`"$botEntry`"" -WorkingDirectory $projectRoot
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $currentUser
$principal = New-ScheduledTaskPrincipal -UserId $currentUser -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet `
    -StartWhenAvailable `
    -RestartCount 999 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -ExecutionTimeLimit ([TimeSpan]::Zero) `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -WakeToRun `
    -MultipleInstances IgnoreNew

Register-ScheduledTask `
    -TaskName $taskName `
    -Action $action `
    -Trigger $trigger `
    -Principal $principal `
    -Settings $settings `
    -Description "Starts Siyaga Prime at logon and retries after an unexpected exit." `
    -Force | Out-Null

$existingListener = Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if ($existingListener) {
    Write-Output "Scheduled task installed. Port 8080 is already listening, so no duplicate bot process was started."
} else {
    Start-ScheduledTask -TaskName $taskName
    Write-Output "Scheduled task installed and started. It will run at logon and retry after an unexpected exit."
}