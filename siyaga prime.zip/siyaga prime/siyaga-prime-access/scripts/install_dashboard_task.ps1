$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $PSScriptRoot
$dashboardRoot = Join-Path $projectRoot "top-gg"
$envPath = Join-Path $projectRoot ".env"
$taskName = "SiyagaPrimeDashboard"

if (-not (Test-Path -LiteralPath $envPath)) {
    throw "The project .env file is missing. Configure dashboard OAuth before installing the task."
}

$envContents = Get-Content -LiteralPath $envPath -Raw
foreach ($requiredKey in @("TOKEN", "DISCORD_CLIENT_ID", "DISCORD_CLIENT_SECRET", "DISCORD_REDIRECT_URI", "DASHBOARD_SECRET_KEY")) {
    if (-not [regex]::IsMatch($envContents, "(?m)^$requiredKey\s*=\s*\S+")) {
        throw "$requiredKey is not configured in .env. Set it privately before installing the dashboard task."
    }
}

$python = (Get-Command python.exe -ErrorAction Stop).Source
$currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$action = New-ScheduledTaskAction -Execute $python -Argument "`"server.py`"" -WorkingDirectory $dashboardRoot
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $currentUser
$principal = New-ScheduledTaskPrincipal -UserId $currentUser -LogonType Interactive -RunLevel Limited
$settings = New-ScheduledTaskSettingsSet `
    -StartWhenAvailable `
    -RestartCount 999 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -ExecutionTimeLimit ([TimeSpan]::Zero) `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -WakeToRun `
    -MultipleInstances IgnoreNew

Register-ScheduledTask `
    -TaskName $taskName `
    -Action $action `
    -Trigger $trigger `
    -Principal $principal `
    -Settings $settings `
    -Description "Starts the Siyaga Prime dashboard at logon and retries after an unexpected exit." `
    -Force | Out-Null

$existingListener = Get-NetTCPConnection -LocalPort 8081 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if ($existingListener) {
    Write-Output "Dashboard task installed. Port 8081 is already listening, so no duplicate process was started."
} else {
    Start-ScheduledTask -TaskName $taskName
    Write-Output "Dashboard task installed and started. It will run at logon and retry after an unexpected exit."
}