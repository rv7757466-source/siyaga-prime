import os

TOKEN = os.environ.get("TOKEN")
NAME = "Siyaga Prime"
server = "https://discord.gg/MMsQ24MpB5"
ch = "https://discord.com/channels/699587669059174461/1271825678710476911"
OWNER_IDS = [1511052482153812182]
BotName = "Siyaga Prime"
serverLink = "https://discord.gg/MMsQ24MpB5"