# Discloud Deployment

This repository is configured as a Discloud Python bot (`TYPE=bot`, `MAIN=main.py`). The bot runs independently of your PC after it has been uploaded and started in Discloud.

## Configure secrets

Do not upload `.env` or commit real credentials. The `.discloudignore` excludes `.env`; set variables in the Discloud dashboard under the app's environment-variable settings before starting it.

Required:

- `TOKEN`: a freshly rotated Discord bot token. The bot cannot log in without it.

Optional integrations:

- `COMMAND_LOG_WEBHOOK_URL`
- `RAPIDAPI_KEY`
- `GIPHY_API_KEY`
- `GOOGLE_API_KEY`
- `GOOGLE_SEARCH_ENGINE_ID`
- `OPENWEATHER_API_KEY`
- `SPOTIFY_CLIENT_ID`
- `SPOTIFY_CLIENT_SECRET`
- `AI_API_KEY`

Optional integrations without credentials stay disabled or show a configuration message; they do not prevent the bot from starting. `.env.example` lists the names without containing values.

## Upload and start

1. In the Discloud dashboard, create a bot application.
2. Add `TOKEN` to the app's environment variables. Add optional integration keys only if you want those features.
3. In the Discord Developer Portal, open **Bot** and enable **Message Content Intent** so prefix commands (for example, `$help`) can be read. Enable any other privileged intents requested by Discord.py in the same panel.
4. Upload `SiyagaPrime-Discloud.zip` with `discloud.config` at the ZIP root.
5. Start the app from the Discloud dashboard.
6. Check the application logs for `Loaded extension: cogs`, `Loaded & Online!`, and a successful Discord login. If cog loading fails, startup now fails and reports the error instead of leaving an online bot with no commands.

`AUTORESTART=true` is already enabled in `discloud.config`. Current Discloud documentation says automatic crash restart requires Platinum or higher. If the account plan does not support it, upgrade the plan or use an external process monitor.

For uptime while your PC is shut down, the app must be running on Discloud, not from a local terminal. Discloud outages, Discord outages, invalidated tokens, and platform plan limits can still interrupt service; no setup can guarantee literally zero downtime.
